package com.dbs.springsecuritydemo.dto;

public enum ERole {
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_ADMIN
}
